# a: int = -1 + 2 + 3 + 4
# a: int = 1 - 2 - 3 - 4

# a = 1*2*3
# b = """ajbaisbd asf
# sd fas as
# df 
# asdf 
# asd
#  fasd
#   fa
#   sdf 
#   asdf 
#   asbfd
  
  
#   asdf asdf asdf 
  
#    asdf """

# print(b)

# a = 4 if true else 5
# if a == 4:
#     d: int = 14
 
# class main():
#     d += 12

# y: int = 5|6|7 * 9 << 1 + 0 
# z: float = 1 << 2 << 3 >> 3 >> 2
# x = 2^5*4+4-3**43&1>>3<<1

# print(x)
    
# a = """str'ing"""
# a = '''str"iong'''
# a = 'str'ing'
# a = "str"ing"
# print(a)
def pow(base, exponent=2):
    return base ** exponent

