# a: int = -1 + 2 + 3 + 4
# a: int = 1 - 2 - 3 - 4

a = 1*2*3
b = """ajbaisbd asf
sd fas as
df 
asdf 
asd
 fasd
  fa
  sdf 
  asdf 
  asbfd
  
  
  asdf asdf asdf 
  
   asdf """

print(b)

a = 4 if true else 5
