def main():
    if 1:
        print("hello")
    else: 
        print("world")
    else:    
        print("error")
