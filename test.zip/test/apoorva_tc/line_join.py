# a:int = 5
# b:int \
# = 5
# print(b)


# li = [5,5,
#       6,8]
# print(li)


# def foo(a, 
#         b):
#     print(a+b)

# foo([5,6],
#     [4,
#      8] )

# d:int
# d:int = 5 + 6
# a = b = 4 + c = d

a = [[5,4],[6,7]]
