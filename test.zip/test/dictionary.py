a:dict[int, str] = {2: "sdofn", 1: "asdb"}
