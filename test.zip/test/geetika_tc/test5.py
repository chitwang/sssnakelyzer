a=[arr[i][j] for j in courses[i] if a > b]


a=b=c=5

a>b>c
