# for j in range(0, len(array) - i - 1):
#     a=4
# for j in range(0,0, len(array) - i - 1,):
#     a=5
# for j in range(0,0, len(array) - i - 1):
#         a=5
# for j in range(0,):
#          a=5
class ShiftReduceParser:

  def _init(self, name: str):
    self.srname: str = name_
    dance = 10

