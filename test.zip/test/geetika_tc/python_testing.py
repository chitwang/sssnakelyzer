for i in range(2):
        x = 5
        print(x)
        for i in range(2):
                print(x)
                
                print(x)
        print(y)
