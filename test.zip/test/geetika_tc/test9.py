class ShiftReduceParser:

  def __init__(self, name_: str):
    self.srname.geet: str = name_


