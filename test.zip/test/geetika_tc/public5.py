def fun(p, q, r):
    a, b, c = 1, 2, 3

