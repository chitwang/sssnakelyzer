class Duck:
	def fly(self):
		print("Duck flying")
class Sparrow:
	def fly(self):
		print("Sparrow flying")
class Whale:
	def swim(self):
		print("Whale swimming")
		a = 5
		if a == 5:
			return "hi"
		else:
			return 90
	def fly(self):
		print("This is not possible")
for animal in Duck (), Sparrow (), Whale ():
	animal.fly()
