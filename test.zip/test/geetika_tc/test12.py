def fun(p, q, r):
    # a, b, c = 1, 2, 3
    *data: list[int]
    for i in range(1):
        x = 1
