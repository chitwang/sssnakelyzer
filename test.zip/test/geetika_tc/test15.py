data = [1,2,3]
for i,j,k in data, data, data:
    print(i,j,k)
