a = b if c else d if c else d
