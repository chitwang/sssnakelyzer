"string" 'hello' "world"
