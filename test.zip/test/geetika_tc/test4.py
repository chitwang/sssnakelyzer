def func():
    print("hello")
a=5
func()
