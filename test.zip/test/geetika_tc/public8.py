class myclass(a, b, c):
    x: int = 5

