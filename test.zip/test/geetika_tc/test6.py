a>b>c
c<b<a
x>a<z
a=a<b
